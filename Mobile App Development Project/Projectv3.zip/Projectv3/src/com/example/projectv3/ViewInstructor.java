package com.example.projectv3;
import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
public class ViewInstructor extends ListActivity {
	public static final String ROW_ID = "row_id"; // Intent extra key
	private ListView viewProfessorListView; // the ListActivity's ListView
	private CursorAdapter professorAdapter; // adapter for ListView
	private int instructorOrTa=1;
	@SuppressLint("ResourceAsColor")
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		viewProfessorListView=getListView();
		viewProfessorListView.setOnItemClickListener(viewProfessorTaListViewListener);
		viewProfessorListView.setBackgroundColor(Color.BLACK);
		Bundle extras=getIntent().getExtras();
		if(extras!=null)
		{
			instructorOrTa=extras.getInt("InstructorOrTa");
		}
		
	}
	@Override
	protected void onResume()
	{
		super.onResume();
		saveInstructorOrTa();

	}

	public void saveInstructorOrTa()
	{
		String from[]={"name"};
		int to[]={R.id.professorTaTextView};
		professorAdapter = new SimpleCursorAdapter(ViewInstructor.this, R.layout.instructor_ta_view, null, from, to);
		setListAdapter(professorAdapter);
		new GetProfessorTaList().execute((Object[])null);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		MenuInflater inflator=getMenuInflater();
		inflator.inflate(R.menu.instructor_ta_view_menu, menu);


		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case R.id.addNewInstructor:
			Intent addNewInstructor= new Intent(ViewInstructor.this,AddEditInstructorTa.class);
			startActivity(addNewInstructor);
			return super.onOptionsItemSelected(item);

		case R.id.showTAs:
			instructorOrTa=2;
			saveInstructorOrTa();
			return super.onOptionsItemSelected(item);
			
		case R.id.showInstructors:
			instructorOrTa=1;
			saveInstructorOrTa();
			return super.onOptionsItemSelected(item);
			
		case R.id.keyOutcomes:
			Intent keyOutcomes= new Intent(ViewInstructor.this,KeyOutcomes.class);
			startActivity(keyOutcomes);
			return super.onOptionsItemSelected(item);

			

		default: return super.onOptionsItemSelected(item);
		}
	}

	@Override
	protected void onStop()
	{
		Cursor cursor=professorAdapter.getCursor();
		if(cursor!=null)
		{
			cursor.deactivate();

		}
		professorAdapter.changeCursor(null);
		super.onStop();
	}

	private class GetProfessorTaList extends AsyncTask<Object,Object,Cursor>
	{
		Cursor result;
		DatabaseConnector databaseConnector=new DatabaseConnector(ViewInstructor.this);

		@Override
		protected Cursor doInBackground(Object... params)
		{
			if(instructorOrTa==1)
			{
				result=databaseConnector.getAllInstructors();
			}
			else
			{
				result=databaseConnector.getAllTa();
			}
			

			return result;
		}

		@Override
		protected void onPostExecute(Cursor result)
		{
			professorAdapter.changeCursor(result);
		}

	}

	OnItemClickListener viewProfessorTaListViewListener = new OnItemClickListener()
	{
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3)
		{
			
			Intent viewInstructorTaDetails= new Intent(ViewInstructor.this,ViewInstructorTaDetails.class);
			viewInstructorTaDetails.putExtra("rowID",arg3);
			viewInstructorTaDetails.putExtra("InstructorOrTa", instructorOrTa);
			startActivity(viewInstructorTaDetails);
		}
	};


}
