package com.example.projectv3;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
public class KeyOutcomes extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState); // call super's onCreate
		setContentView(R.layout.key_outcome_tracker_tool);
		Button studySession=(Button)findViewById(R.id.studySession);
		Button viewTA=(Button)findViewById(R.id.viewTA);
		Button viewClassActivities=(Button)findViewById(R.id.viewClassActivities);
		Button trackActivities=(Button)findViewById(R.id.trackActivities);
		ImageButton studentProfile=(ImageButton)findViewById(R.id.studentProfileImageButton);
		ImageButton informationImageButton=(ImageButton)findViewById(R.id.informationImageButton);
		informationImageButton.setOnClickListener(informationImageButtonListener);
		studentProfile.setOnClickListener(studentProfileListener);
		viewTA.setOnClickListener(viewTaListener);
		studySession.setOnClickListener(studySessionButtonListener);
	}
	OnClickListener studySessionButtonListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{

			Toast.makeText(KeyOutcomes.this, "Opening View study sessions...", Toast.LENGTH_SHORT).show();
			Intent viewClasses= new Intent(KeyOutcomes.this,ViewClasses.class);
			startActivity(viewClasses);
		}
		
	};
	
	OnClickListener viewTaListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			Toast.makeText(KeyOutcomes.this, "Opening View TA and Instructor...", Toast.LENGTH_SHORT).show();
			Intent viewInstructor= new Intent(KeyOutcomes.this,ViewInstructor.class);
			startActivity(viewInstructor);
		}
	};
	
	OnClickListener studentProfileListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			Toast.makeText(KeyOutcomes.this, "Opening Student Profile...", Toast.LENGTH_SHORT).show();
			Intent studentProfile= new Intent(KeyOutcomes.this,StudentProfile.class);
			startActivity(studentProfile);
			
		}
	};
	
	OnClickListener informationImageButtonListener= new OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			Toast.makeText(KeyOutcomes.this, "Showing Contact US...", Toast.LENGTH_SHORT).show();
			Intent contactUs= new Intent(KeyOutcomes.this,ContactUs.class);
			startActivity(contactUs);
		}
	};

	
	

}
