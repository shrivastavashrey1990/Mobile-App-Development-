package com.example.projectv3;


import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.view.LayoutInflater;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
public class AddEditInstructorTa extends Activity {
	private long rowId_instructor;
	private EditText nameEditText;
	private EditText officeEditText;
	private EditText emailEditText;
	private EditText phoneEditText;
	private TableLayout officeHourTableLayout;
	private RadioButton instructorRadioButton;
	private RadioButton taRadioButton;
	private String instructorOrTa="instructor";
	private int iorT;
	private long rowID;
	private long rowId_Ta;
	private Cursor officeHours;
	private Bundle extras;
	private static Long officeHoursId[]=new Long[4000];

	@Override 
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_edit_instructor_ta);

		nameEditText = (EditText)findViewById(R.id.nameEditText);
		officeEditText = (EditText)findViewById(R.id.officeEditText);
		emailEditText = (EditText)findViewById(R.id.emailEditText);
		phoneEditText = (EditText)findViewById(R.id.phoneEditText);
		officeHourTableLayout = (TableLayout) findViewById(R.id.officeHourTableLayout);
		instructorRadioButton=(RadioButton)findViewById(R.id.instructorRadioButton);
		taRadioButton=(RadioButton)findViewById(R.id.taRadioButton);

		taRadioButton.setOnCheckedChangeListener(taRadioButtonListener);
		instructorRadioButton.setOnCheckedChangeListener(instructorRadioButtonListener);

		Button monButton=(Button)findViewById(R.id.monButton);
		Button tueButton=(Button)findViewById(R.id.tueButton);
		Button wedButton=(Button)findViewById(R.id.wedButton);
		Button thuButton=(Button)findViewById(R.id.thuButton);
		Button friButton=(Button)findViewById(R.id.friButton);
		Button satButton=(Button)findViewById(R.id.satButton);
		Button saveAndAddButton=(Button)findViewById(R.id.saveAddButton);
		Button saveFinishButton=(Button)findViewById(R.id.saveFinishButton);


		monButton.setOnClickListener(daysButtonListener);
		tueButton.setOnClickListener(daysButtonListener);
		wedButton.setOnClickListener(daysButtonListener);
		thuButton.setOnClickListener(daysButtonListener);
		friButton.setOnClickListener(daysButtonListener);
		satButton.setOnClickListener(daysButtonListener);

		saveAndAddButton.setOnClickListener(saveAndAddButtonListener);
		saveFinishButton.setOnClickListener(saveAndFinishButtonListener);

		extras=getIntent().getExtras();
		if(extras!=null)
		{
			nameEditText.setText(extras.getString("Name"));
			officeEditText.setText(extras.getString("OfficeLocation"));
			emailEditText.setText(extras.getString("Email"));
			phoneEditText.setText(extras.getString("PhoneNumber"));
			iorT=extras.getInt("instructorOrTa");
			rowID=extras.getLong("ID");
			saveAndAddButton.setFocusable(false);
			saveAndAddButton.setEnabled(false);
			if(iorT==1)
			{
				instructorRadioButton.setChecked(true);
				taRadioButton.setEnabled(false);
				
			}
			else
			{
				taRadioButton.setChecked(true);
				instructorRadioButton.setEnabled(false);
			}
			
			new LoadOfficeHours().execute(rowID);



		}
	}

	private class LoadOfficeHours extends AsyncTask<Long,Object,Cursor>
	{
		DatabaseConnector databaseconnector=new DatabaseConnector(AddEditInstructorTa.this);
		@Override
		protected Cursor doInBackground(Long... params)
		{
			if(iorT==1)
			{
				officeHours=databaseconnector.getInstructorOfficeHours(params[0]);	
			}
			else
			{
				officeHours=databaseconnector.getTaOfficeHours(params[0]);	
			}
			return officeHours;
		}

		@Override
		protected void onPostExecute(Cursor result)
		{
			super.onPostExecute(result);
			int i=result.getCount();
			i=i+0;

			result.moveToFirst();
			for(int z=1;z<=i;z++)
			{
				LayoutInflater inflater=(LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View addEditInstructorTaOfficeHourView = inflater.inflate(R.layout.new_office_hour_row, null);

				// get references to day, start time, and end time
				TextView dayTextView = (TextView) addEditInstructorTaOfficeHourView.findViewById(R.id.dayTextView);
				int officeDay=result.getColumnIndex("officeDay");
				dayTextView.setText(result.getString(officeDay));

				EditText startTimeEditText = (EditText) addEditInstructorTaOfficeHourView.findViewById(R.id.startTimeEditText);
				int startTime=officeHours.getColumnIndex("startTime");
				startTimeEditText.setText(result.getString(startTime));

				EditText endTimeEditText = (EditText) addEditInstructorTaOfficeHourView.findViewById(R.id.endTimeEditText);
				int endTime=officeHours.getColumnIndex("endTime");
				endTimeEditText.setText(result.getString(endTime));

				Button delOfficeHourButton = 
						(Button) addEditInstructorTaOfficeHourView.findViewById(R.id.delOfficeHourButton); 
				delOfficeHourButton.setOnClickListener(delOfficeHourListener);


				officeHourTableLayout.addView(addEditInstructorTaOfficeHourView);
				result.moveToNext();

			}
			result.close();
		}


	}

	OnClickListener daysButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(final View v)
		{
			makeOfficeHourGUI(v.getId());
		}
	};
	OnCheckedChangeListener taRadioButtonListener= new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			// TODO Auto-generated method stub
			if(isChecked==true)
			{
				instructorRadioButton.setChecked(false);
				instructorOrTa="ta";
			}


		}
	};



	OnClickListener saveAndAddButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if( nameEditText.getText().toString().trim().length()>0)
			{
				AsyncTask<Object, Object, Object> saveTask= new AsyncTask<Object,Object,Object>()
						{
					@Override
					protected Object doInBackground(Object... params)
					{
						if(instructorOrTa.trim().equalsIgnoreCase("instructor"))
						{
							if(extras!=null)
							{
								updateInstructor();
							}
							else
							{
								saveInstructor();
							}

						}
						else
						{
							if(extras!=null)
							{
								updateTa();
							}
							else
							{
								saveTa();
							}

						}

						return null;
					}

					@Override
					protected void onPostExecute(Object result)
					{
						nameEditText.setText("");
						officeEditText.setText("");
						emailEditText.setText("");
						phoneEditText.setText("");
						officeHourTableLayout.removeAllViews();

					}

						};
						saveTask.execute((Object[])null);
			}
			else
			{
				AlertDialog.Builder builder= new AlertDialog.Builder(AddEditInstructorTa.this);
				builder.setTitle(R.string.errorTitle);
				builder.setMessage(R.string.errorMessage);
				builder.setPositiveButton(R.string.errorButton, null);
				builder.show();
			}
		}
	};

	private void saveInstructor()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		rowId_instructor=databaseConnector.insertInstructor(nameEditText.getText().toString().trim(), officeEditText.getText().toString().trim(), phoneEditText.getText().toString().trim(),emailEditText.getText().toString().trim());


		for (int i = 0; i < officeHourTableLayout.getChildCount(); i++)
		{
			TableRow officeHourTableRow = (TableRow) officeHourTableLayout.getChildAt(i);

			officeHoursId[i]=databaseConnector.insertOfficeHours(
					((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
					((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
					((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
					rowId_instructor, 0);
		}		
	}

	public void saveTa()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		rowId_Ta=databaseConnector.insertTa(nameEditText.getText().toString().trim(), officeEditText.getText().toString().trim(), phoneEditText.getText().toString().trim(),emailEditText.getText().toString().trim());
		for (int i = 0; i < officeHourTableLayout.getChildCount(); i++)
		{
			TableRow officeHourTableRow = (TableRow) officeHourTableLayout.getChildAt(i);

			databaseConnector.insertOfficeHours(
					((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
					((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
					((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
					0, rowId_Ta);
		}		
	}
	public void updateInstructor()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		rowId_instructor=databaseConnector.updateInstructor(nameEditText.getText().toString().trim(), officeEditText.getText().toString().trim(), phoneEditText.getText().toString().trim(),emailEditText.getText().toString().trim(),rowID);
		int noOfRows=officeHourTableLayout.getChildCount();
		for (int i = 0; i < officeHourTableLayout.getChildCount(); i++)
		{
			//officeHoursId[i]=officeHoursId[i]+0;
			if(officeHoursId[i]==null)
			{
				officeHoursId[i]=0L;
			}
			TableRow officeHourTableRow = (TableRow) officeHourTableLayout.getChildAt(i);
			databaseConnector.updateOfficeHoursForInstructors(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
					((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
					((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
					rowID, 0,officeHoursId[i]);


		}
		DatabaseConnector.count=0;

	}

	public void updateTa()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		rowId_Ta=databaseConnector.updateTa(nameEditText.getText().toString().trim(), officeEditText.getText().toString().trim(), phoneEditText.getText().toString().trim(),emailEditText.getText().toString().trim(),rowID);
		for (int i = 0; i < officeHourTableLayout.getChildCount(); i++)
		{
			if(officeHoursId[i]==null)
			{
				officeHoursId[i]=0L;
			}
			TableRow officeHourTableRow = (TableRow) officeHourTableLayout.getChildAt(i);
			databaseConnector.updateOfficeHoursForTa(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
					((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
					((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
					0, rowID,officeHoursId[i]);
		}
		DatabaseConnector.count=0;
	}
	OnCheckedChangeListener instructorRadioButtonListener= new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			// TODO Auto-generated method stub
			if(isChecked==true)
			{
				taRadioButton.setChecked(false);
				instructorOrTa="instructor";
			}


		}
	};

	OnClickListener saveAndFinishButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if( nameEditText.getText().toString().trim().length()>0)
			{
				AsyncTask<Object, Object, Object> saveTask= new AsyncTask<Object,Object,Object>()
						{
					@Override
					protected Object doInBackground(Object... params)
					{
						if(instructorOrTa.trim().equalsIgnoreCase("instructor"))
						{
							if(extras!=null)
							{
								
								updateInstructor();
							}
							else
							{
								saveInstructor();
							}

						}
						else
						{
							if(extras!=null)
							{
								updateTa();
							}
							else
							{
								saveTa();
							}

						}

						return null;
					}

					@Override
					protected void onPostExecute(Object result)
					{
						if(extras!=null)
						{
							Intent viewInstructorTaDetails1=new Intent(AddEditInstructorTa.this,ViewInstructorTaDetails.class);
							viewInstructorTaDetails1.putExtra("rowID", rowID);
							viewInstructorTaDetails1.putExtra("InstructorOrTa", iorT);
							startActivity(viewInstructorTaDetails1);
							
						}
						else
						{
							finish();
						}
						

					}

						};
						saveTask.execute((Object[])null);
			}
			else
			{
				AlertDialog.Builder builder= new AlertDialog.Builder(AddEditInstructorTa.this);
				builder.setTitle(R.string.errorTitle);
				builder.setMessage(R.string.errorMessage);
				builder.setPositiveButton(R.string.errorButton, null);
				builder.show();
			}	
		}
	};

	private void makeOfficeHourGUI(int dayId)
	{
		// get a reference to the LayoutInflater service
		LayoutInflater inflater = (LayoutInflater) getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);

		// inflate new_office_hour_row.xml to create new office hour row
		View newOfficeHourView = inflater.inflate(R.layout.new_office_hour_row, null);

		// get references to day, start time, and end time
		TextView dayTextView = (TextView) newOfficeHourView.findViewById(R.id.dayTextView);
		switch (dayId)
		{
		case R.id.monButton: 
			dayTextView.setText("Mon");
			break;
		case R.id.tueButton: 
			dayTextView.setText("Tue");
			break;
		case R.id.wedButton: 
			dayTextView.setText("Wed");
			break;
		case R.id.thuButton: 
			dayTextView.setText("Thu");
			break;
		case R.id.friButton: 
			dayTextView.setText("Fri");
			break;
		case R.id.satButton: 
			dayTextView.setText("Sat");
			break;
		}

		EditText startTimeEditText = (EditText) newOfficeHourView.findViewById(R.id.startTimeEditText);
		startTimeEditText.setHint("Start time");
		EditText endTimeEditText = (EditText) newOfficeHourView.findViewById(R.id.endTimeEditText);
		endTimeEditText.setHint("End time");

		// get delOfficeHourButton and register its listener
		Button delOfficeHourButton = 
				(Button) newOfficeHourView.findViewById(R.id.delOfficeHourButton); 
		delOfficeHourButton.setOnClickListener(delOfficeHourListener);

		// add new office hour row to officeHourTableLayout
		officeHourTableLayout.addView(newOfficeHourView);
	} // end makeOfficeHourGUI

	OnClickListener delOfficeHourListener=new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if(extras!=null)
			{
				DatabaseConnector databaseConnector = new DatabaseConnector(AddEditInstructorTa.this);
				if(iorT==1)
				{
					
					TableLayout table = (TableLayout)findViewById(R.id.officeHourTableLayout);
					TableRow officeHourTableRow=(TableRow)v.getParent();
					Cursor result=databaseConnector.checkOfficeHourDayExistenceForInstructor(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), rowID);
					if(result.getCount()>0)
					{
						databaseConnector.deleteInstructorOfficeHours(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
								((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
								((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
								rowID, 0);
						table.removeView(officeHourTableRow);
	
					}
					else
					{
						table.removeView(officeHourTableRow);
					}
					
				}
				else
				{
					TableLayout table = (TableLayout)findViewById(R.id.officeHourTableLayout);
					TableRow officeHourTableRow=(TableRow)v.getParent();
					Cursor result=databaseConnector.checkOfficeHourDayExistenceForTa(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), rowID);
					if(result.getCount()>0)
					{
						databaseConnector.deleteTaOfficeHours(((TextView) officeHourTableRow.getChildAt(0)).getText().toString(), //day
								((EditText) officeHourTableRow.getChildAt(1)).getText().toString(), //start time
								((EditText) officeHourTableRow.getChildAt(2)).getText().toString(), //end time
								0, rowID);
						table.removeView(officeHourTableRow);

					}
					else
					{
						table.removeView(officeHourTableRow);
					}
					
					
				}


			}
			else
			{
				TableLayout table = (TableLayout)findViewById(R.id.officeHourTableLayout);
				TableRow officeHourTableRow=(TableRow)v.getParent();
				table.removeView(officeHourTableRow);

			}
		}
	};

}
