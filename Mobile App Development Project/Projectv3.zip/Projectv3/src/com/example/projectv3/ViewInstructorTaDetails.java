package com.example.projectv3;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class ViewInstructorTaDetails extends Activity {
	private TextView nameTextView;
	private TextView officeLocationtextView;
	private TextView emailTextView;
	private TextView phoneTextView;
	private TextView hoursTextView;
	private long rowId;
	private int instructorOrTa;
	private Cursor c;
	private Cursor officeHours;
	private TableLayout hourTableLayout;


	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_instructor_ta_details);
		nameTextView=(TextView)findViewById(R.id.nametextView);
		officeLocationtextView=(TextView)findViewById(R.id.officeLocationtextView);
		emailTextView=(TextView)findViewById(R.id.emailTextView);
		phoneTextView=(TextView)findViewById(R.id.phoneTextView);
		hoursTextView=(TextView)findViewById(R.id.hoursTextView);
		hourTableLayout=(TableLayout)findViewById(R.id.hourTableLayout);
		Button editButton= (Button)findViewById(R.id.saveLocationAndDescrptionButton);
		editButton.setOnClickListener(editButtonListener);

		Button deleteButton=(Button)findViewById(R.id.classDeleteViewButton);
		deleteButton.setOnClickListener(deleteButtonListener);

		Bundle extras=getIntent().getExtras();
		rowId=extras.getLong("rowID");
		instructorOrTa=extras.getInt("InstructorOrTa");

	}

	@Override
	protected void onResume()
	{
		super.onResume();
		new LoadInfo().execute(rowId);
	}

	OnClickListener deleteButtonListener= new OnClickListener() {
		@Override
		public void onClick(View v) 
		{
			DatabaseConnector databaseconnector=new DatabaseConnector(ViewInstructorTaDetails.this);
			if(instructorOrTa==1)
			{
				databaseconnector.deleteInstructor(rowId);
				databaseconnector.deleteSpecificInstructorOfficeHours(rowId);
				hourTableLayout.removeAllViews();
				Intent showInstructor= new Intent(ViewInstructorTaDetails.this,ViewInstructor.class);
				showInstructor.putExtra("InstructorOrTa", instructorOrTa);
				startActivity(showInstructor);
				
			}
			else
			{
				databaseconnector.deleteTa(rowId);
				databaseconnector.deleteSpecificTaOfficeHours(rowId);
				hourTableLayout.removeAllViews();
				Intent showTa= new Intent(ViewInstructorTaDetails.this,ViewInstructor.class);
				showTa.putExtra("InstructorOrTa", instructorOrTa);
				startActivity(showTa);
				
			}
		} 
	};
	OnClickListener editButtonListener= new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent addEditInstructorTa= new Intent(ViewInstructorTaDetails.this,AddEditInstructorTa.class);
			addEditInstructorTa.putExtra("Name",nameTextView.getText().toString().trim());
			addEditInstructorTa.putExtra("OfficeLocation",officeLocationtextView.getText().toString().trim());
			addEditInstructorTa.putExtra("Email",emailTextView.getText().toString().trim());
			addEditInstructorTa.putExtra("PhoneNumber",phoneTextView.getText().toString().trim());
			addEditInstructorTa.putExtra("instructorOrTa", instructorOrTa);
			addEditInstructorTa.putExtra("ID", rowId);

			hourTableLayout.removeAllViews();

			startActivity(addEditInstructorTa);

		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		MenuInflater inflator=getMenuInflater();
		inflator.inflate(R.menu.instructor_ta_view_menu, menu);


		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case R.id.addNewInstructor:
			Intent addNewInstructor= new Intent(ViewInstructorTaDetails.this,AddEditInstructorTa.class);
			startActivity(addNewInstructor);
			return super.onOptionsItemSelected(item);

		case R.id.showInstructors:
			Intent showInstructor= new Intent(ViewInstructorTaDetails.this,ViewInstructor.class);
			showInstructor.putExtra("InstructorOrTa", instructorOrTa);
			startActivity(showInstructor);
			return super.onOptionsItemSelected(item);

		case R.id.showTAs:
			Intent showTa= new Intent(ViewInstructorTaDetails.this,ViewInstructor.class);
			showTa.putExtra("InstructorOrTa", instructorOrTa);
			startActivity(showTa);
			return super.onOptionsItemSelected(item);
			
		case R.id.keyOutcomes:
			Intent keyOutcomes= new Intent(ViewInstructorTaDetails.this,KeyOutcomes.class);
			startActivity(keyOutcomes);
			return super.onOptionsItemSelected(item);


		default: return super.onOptionsItemSelected(item);
		}
	}


	private class LoadInfo extends AsyncTask<Long,Object,Cursor>
	{
		DatabaseConnector databaseconnector=new DatabaseConnector(ViewInstructorTaDetails.this);
		@Override
		protected Cursor doInBackground(Long... params)
		{
			if(instructorOrTa==1)
			{
				c=databaseconnector.getInstructor(params[0]);
			}
			else
			{
				c=databaseconnector.getTa(params[0]);
			}
			return c;
		}

		@Override
		protected void onPostExecute(Cursor result)
		{
			super.onPostExecute(result);
			int b=result.getCount();
			b=b+0;
			result.moveToFirst();
			int name=result.getColumnIndex("name");
			int office=result.getColumnIndex("office");
			int phone=result.getColumnIndex("phone");
			int email=result.getColumnIndex("email");

			nameTextView.setText(result.getString(name));
			officeLocationtextView.setText(result.getString(office));
			phoneTextView.setText(result.getString(phone));
			emailTextView.setText(result.getString(email));
			result.close();
			if(instructorOrTa==1)
			{
				officeHours=databaseconnector.getInstructorOfficeHours(rowId);	
			}
			else
			{
				officeHours=databaseconnector.getTaOfficeHours(rowId);	
			}

			int i=officeHours.getCount();
			officeHours.moveToFirst();
			for(int z=1;z<=i;z++)
			{
				LayoutInflater inflater=(LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View newViewDetails=inflater.inflate(R.layout.view_details, null);

				TextView nameTextView=(TextView)newViewDetails.findViewById(R.id.nametextView);
				int officeDay=officeHours.getColumnIndex("officeDay");
				String s=officeHours.getString(officeDay);
				System.out.println(s);
				nameTextView.setText(officeHours.getString(officeDay));

				TextView startTimeTextView=(TextView)newViewDetails.findViewById(R.id.courseNumberTextView);
				int startTime=officeHours.getColumnIndex("startTime");
				startTimeTextView.setText(officeHours.getString(startTime));

				TextView endTimeTextView=(TextView)newViewDetails.findViewById(R.id.textView3);
				int endTime=officeHours.getColumnIndex("endTime");
				endTimeTextView.setText(officeHours.getString(endTime));

				hourTableLayout.addView(newViewDetails);
				officeHours.moveToNext();

			}
			officeHours.close();


		}
	}

}
