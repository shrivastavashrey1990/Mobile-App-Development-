package com.example.projectv3;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.view.LayoutInflater;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;

public class EnterClassLocationAndDescription extends Activity {
	private EditText classLocationEditText;
	private EditText classDescriptionEditText;
	private Spinner spinnerInstructorName;
	private Spinner spinnerTaName;
	private Bundle extras;
	private long classID;
	private List<String> instructorNamesList;
	private List<String> taNamesList;
	private Cursor result;

	@Override 
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_class_location_description_instructor_and_ta_view);
		classLocationEditText=(EditText)findViewById(R.id.classLocationEditText);
		classDescriptionEditText=(EditText)findViewById(R.id.classDescriptionEditText);
		spinnerInstructorName=(Spinner)findViewById(R.id.spinnerInstructorName);
		spinnerTaName=(Spinner)findViewById(R.id.spinnerTaName);

		Button addButtonForClass=(Button)findViewById(R.id.addButtonForClass);
		addButtonForClass.setOnClickListener(addButtonForClassListener);

		Button deleteButtonForClass=(Button)findViewById(R.id.deleteButtonForClass);
		deleteButtonForClass.setOnClickListener(deleteButtonForClassListener);
		
		Button addButtonTaForClass=(Button)findViewById(R.id.addButtonTaForClass);
		addButtonTaForClass.setOnClickListener(addButtonTaForClassListener);
		
		Button deleButtonTaForClass=(Button)findViewById(R.id.deleteButtonTaForClass);
		deleButtonTaForClass.setOnClickListener(deleButtonTaForClassListener);

		Button saveLocationAndDescrptionButton=(Button)findViewById(R.id.saveLocationAndDescrptionButton);
		saveLocationAndDescrptionButton.setOnClickListener(saveLocationAndDescrptionButtonListener);

		extras=getIntent().getExtras();
		classID=extras.getLong("classID");
		addItemsOnInstructorSpinner();
		addItemsOnTaSpinner();



	}

	public void addItemsOnInstructorSpinner()
	{
		instructorNamesList=new ArrayList<String>();
		DatabaseConnector databaseConnector=new DatabaseConnector(this);
		result=databaseConnector.getAllInstructors();
		int count=result.getCount();
		
		if(count>0)
		{
			result.moveToFirst();
			for(int a=1;a<=count;a++)
			{
				int nameIndex=result.getColumnIndex("name");
				String s=result.getString(nameIndex);
				System.out.println(s);
				instructorNamesList.add(result.getString(nameIndex));
				result.moveToNext();
			}
			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, instructorNamesList);

			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerInstructorName.setAdapter(dataAdapter);
			result.close();

		}
		
	}

	public void addItemsOnTaSpinner()
	{
		taNamesList=new ArrayList<String>();
		DatabaseConnector databaseConnector=new DatabaseConnector(this);
		result=databaseConnector.getAllTa();
		int count=result.getCount();
		if(count>0)
		{
			
			result.moveToFirst();
			for(int a=1;a<=count;a++)
			{
				int nameIndex=result.getColumnIndex("name");
				taNamesList.add(result.getString(nameIndex));
				result.moveToNext();
			}

			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, taNamesList);

			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerTaName.setAdapter(dataAdapter);
			result.close();

		}
		
	}

	OnClickListener addButtonForClassListener=new OnClickListener() {

		@Override
		public void onClick(View v) {
			DatabaseConnector databaseConnector=new DatabaseConnector(EnterClassLocationAndDescription.this);
			// TODO Auto-generated method stub
			String.valueOf(spinnerInstructorName.getSelectedItem());
			int iD=databaseConnector.getInstructorId(String.valueOf(spinnerInstructorName.getSelectedItem()));
			Cursor verify=databaseConnector.checkInstructorForClass(iD);
			if(verify.getCount()==0)
			{
				databaseConnector.insertInstructorForClass(classID, iD);
			}
			if(verify!=null)
			{
				verify.close();

			}

		}
	};
	
	OnClickListener addButtonTaForClassListener=new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatabaseConnector databaseConnector=new DatabaseConnector(EnterClassLocationAndDescription.this);
			// TODO Auto-generated method stub
			String.valueOf(spinnerTaName.getSelectedItem());
			
			int iD=databaseConnector.getTaId(String.valueOf(spinnerTaName.getSelectedItem()));
			Cursor verify=databaseConnector.checkTaForClass(iD);
			if(verify.getCount()==0)
			{
				databaseConnector.insertTaForClass(classID, iD);
			}
			if(verify!=null)
			{
				verify.close();

			}
			
		}
	};

	OnClickListener deleteButtonForClassListener=new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatabaseConnector databaseConnector=new DatabaseConnector(EnterClassLocationAndDescription.this);
			String.valueOf(spinnerInstructorName.getSelectedItem());
			int iD=databaseConnector.getInstructorId(String.valueOf(spinnerInstructorName.getSelectedItem()));
			Cursor verify=databaseConnector.checkInstructorForClass(iD);
			if(verify.getCount()==0)
			{
				databaseConnector.deleteInstructorForClass(classID, iD);
			}
			if(verify!=null)
			{
				verify.close();

			}
		}
	}; 
OnClickListener deleButtonTaForClassListener=new OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
};
	OnClickListener saveLocationAndDescrptionButtonListener=new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatabaseConnector databaseConnector=new DatabaseConnector(EnterClassLocationAndDescription.this);
			String s=classLocationEditText.getText().toString().trim();
			
			if(classLocationEditText.getText().toString().trim().length()>0 && classDescriptionEditText.getText().toString().trim().length()>0 )
			{
				databaseConnector.updateClassLocationAndDescription(classID, classLocationEditText.getText().toString().trim(), classDescriptionEditText.getText().toString().trim());	

			}
			Intent viewClasses=new Intent(EnterClassLocationAndDescription.this,ViewClasses.class);
			startActivity(viewClasses);
		}
	};

}
