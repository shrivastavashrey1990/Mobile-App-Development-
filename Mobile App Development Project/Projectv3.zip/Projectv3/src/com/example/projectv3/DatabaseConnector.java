package com.example.projectv3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class DatabaseConnector {
	private static final String DATABASE_NAME = "ClassTracker";
	private SQLiteDatabase database; // database object
	private DatabaseOpenHelper databaseOpenHelper; // database helper
	public static int count=0;

	public DatabaseConnector(Context context)
	{
		int dbVersion=1;
		databaseOpenHelper = new DatabaseOpenHelper(context,DATABASE_NAME,null,dbVersion);

	}
	public void open() throws SQLException
	{
		database=databaseOpenHelper.getWritableDatabase();
	}

	public void close()
	{
		if(database!=null)
		{
			database.close();
		}
	}

	public void insertUser(String FirstName, String LastName, String StudentID,String SchoolName, String Description,String Others)
	{
		ContentValues firstUser=new ContentValues();
		firstUser.put("FirstName",FirstName);
		firstUser.put("LastName",LastName);
		firstUser.put("StudentID",StudentID);
		firstUser.put("SchoolName",SchoolName);
		firstUser.put("Description",Description);
		firstUser.put("Others",Others);

		open();
		database.insert("users", null, firstUser);
		close();
	}

	public void updateUser(String FirstName,String LastName,String StudentID,String SchoolName,String Description,String Others)
	{
		ContentValues editUser=new ContentValues();
		editUser.put("FirstName",FirstName);
		editUser.put("LastName",LastName);
		editUser.put("StudentID",StudentID);
		editUser.put("SchoolName",SchoolName);
		editUser.put("Description",Description);
		editUser.put("Others",Others);

		open();
		database.update("users", editUser,"_id=" + 1,null);
		close();
	}

	public Cursor getInstructor(long id)
	{
		open();
		Cursor cu=database.rawQuery("select * from instructors where _id= "+id, null);
		int y=cu.getCount();
		y=y+0;
		close();
		return cu;

	}

	public Cursor getTa(long id)
	{
		open();
		Cursor cu=database.rawQuery("select * from assistants where _id= "+id, null);
		int y=cu.getCount();
		y=y+0;
		close();
		return cu;
	}

	public Cursor getUserInfo()
	{
		open();
		Cursor cu= database.rawQuery("select * from users", null);
		int a= cu.getCount();
		a=a+0;
		close();
		return cu;
	}

	public Cursor getUserDetails(Long ID)
	{
		open();
		Cursor cu=database.rawQuery("select * from users WHERE _id= "+ID, null);
		int z=cu.getCount();
		z=z+0;
		close();
		return cu;
	}
	public Cursor getAllInstructors()
	{
		open();
		Cursor cu=database.rawQuery("select _id,name from instructors order by name", null);
		int y=cu.getCount();
		y=y+0;
		close();
		return cu;
	}

	public long insertInstructor(String name,String office, String phone, String email)
	{
		ContentValues insertInstructor=new ContentValues();
		insertInstructor.put("name", name);
		insertInstructor.put("office",office);
		insertInstructor.put("phone",phone);
		insertInstructor.put("email",email);

		open();
		long rowId=database.insert("instructors", null, insertInstructor);
		close();
		return rowId;


	}

	public long updateInstructor(String name,String office, String phone, String email, long id)
	{
		ContentValues updateInstructor=new ContentValues();
		updateInstructor.put("name", name);
		updateInstructor.put("office",office);
		updateInstructor.put("phone",phone);
		updateInstructor.put("email",email);

		open();
		long rowId=database.update("instructors", updateInstructor,"_id=" + id,null);
		
		close();
		return rowId;


	}

	public long insertTa(String name,String office, String phone, String email)
	{
		ContentValues insertTa=new ContentValues();
		insertTa.put("name", name);
		insertTa.put("office",office);
		insertTa.put("phone",phone);
		insertTa.put("email",email);

		open();
		long rowId=database.insert("assistants", null, insertTa);
		close();
		return rowId;


	}

	public long updateTa(String name,String office, String phone, String email, long id)
	{
		ContentValues updateTa=new ContentValues();
		updateTa.put("name", name);
		updateTa.put("office",office);
		updateTa.put("phone",phone);
		updateTa.put("email",email);

		open();
		long rowId=database.update("assistants", updateTa,"_id=" + id,null);
		close();
		return rowId;


	}

	public long insertOfficeHours(String officeDay,String startTime,String endTime,long instructor_id,long assistant_id)
	{
		ContentValues insertOfficeHours=new ContentValues();
		insertOfficeHours.put("officeDay", officeDay);
		insertOfficeHours.put("startTime", startTime);
		insertOfficeHours.put("endTime", endTime);
		insertOfficeHours.put("instructor_id", instructor_id);
		insertOfficeHours.put("assistant_id", assistant_id);

		open();
		long id=database.insert("officehours", null, insertOfficeHours);
		close();
		return id;
	}
	
	public Cursor checkOfficeHourDayExistenceForInstructor(String officeDay,long id)
	{
		open();
		Cursor cu=database.rawQuery("select * from officehours where officeDay= \""+officeDay+"\" and instructor_id= "+id, null);
		int a=cu.getCount();
		a=a+0;
		
		close();
		return cu;
	}
	
	public Cursor checkClassDayExistence(String classDay,long id)
	{
		open();
		Cursor cu=database.rawQuery("select * from schedules where classDay= \""+classDay+"\" and class_id= "+id, null);
		int a=cu.getCount();
		a=a+0;
		
		close();
		return cu;
	}

	public Cursor checkOfficeHourDayExistenceForTa(String officeDay,long id)
	{
		open();
		Cursor cu=database.rawQuery("select * from officehours where officeDay= \""+officeDay+"\" and assistant_id= "+id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public void updateSchedule(String classDay,String startTime,String endTime,long class_id,long iD)
	{
		count=count+1;
		open();
		Cursor cu=database.rawQuery("select * from schedules where class_id= "+class_id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		ContentValues updateSchedule=new ContentValues();
		updateSchedule.put("classDay", classDay);
		updateSchedule.put("startDate",startTime);
		updateSchedule.put("endDate",endTime);
		updateSchedule.put("class_id", class_id);
		
		if(count>a)
		{
			open();
			database.insert("schedules", null, updateSchedule);
			close();
		}
		else
		{
			open();
			//database.rawQuery("UPDATE officehours SET officeDay = \""+officeDay+"\",startTime= \""+startTime+"\",endTime= \""+endTime+"\",instructor_id= "+instructor_id+",assistant_id= "+assistant_id+" WHERE instructor_id= "+id+" AND officeDay= \""+officeDay+"\"", null);

			database.update("schedules", updateSchedule,"class_id=" + class_id +
			          " and classDay='" + classDay+"'",null);
			close();

		}
		
	}

	public void updateOfficeHoursForInstructors(String officeDay,String startTime,String endTime,long instructor_id,long assistant_id,long id)
	{
		count=count+1;
		open();
		Cursor cu=database.rawQuery("select * from officehours where instructor_id= "+instructor_id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		ContentValues updateOfficeHours=new ContentValues();
		updateOfficeHours.put("officeDay", officeDay);
		updateOfficeHours.put("startTime", startTime);
		updateOfficeHours.put("endTime", endTime);
		updateOfficeHours.put("instructor_id", instructor_id);
		updateOfficeHours.put("assistant_id", assistant_id);
		if(count>a)
		{
			open();
			database.insert("officehours", null, updateOfficeHours);
			close();
		}
		else
		{
			open();
			//database.rawQuery("UPDATE officehours SET officeDay = \""+officeDay+"\",startTime= \""+startTime+"\",endTime= \""+endTime+"\",instructor_id= "+instructor_id+",assistant_id= "+assistant_id+" WHERE instructor_id= "+id+" AND officeDay= \""+officeDay+"\"", null);

			database.update("officehours", updateOfficeHours,"instructor_id=" + instructor_id +
			          " and officeDay='" + officeDay+"'",null);
			close();

		}
			}
	
	public void deleteInstructor(long id)
	{
		open();
		database.delete("instructors", "_id= "+id, null);
		close();
		
	}
	
	public void deleteTa(long id)
	{
		open();
		database.delete("assistants", "_id= "+id, null);
		close();
		
	}
	public void deleteSpecificInstructorOfficeHours(long id)
	{
		open();
		database.delete("officehours", "instructor_id= "+id, null);
		close();
	}
	
	public void deleteSpecificTaOfficeHours(long id)
	{
		open();
		database.delete("officehours", "assistant_id= "+id, null);
		close();
	}
	
	public void deleteInstructorOfficeHours(String officeDay,String startTime,String endTime,long instructor_id,long assistant_id)
	{
		open();
		database.delete("officeHours", "instructor_id=" + instructor_id +
		          " and officeDay='" + officeDay +
		          "' and startTime='" + startTime +
		          "' and endTime='" + endTime + "'", null);
		close();
	}
	
	public void deleteClassDays(String classDay,String startDate,String endDate,long class_id)
	{
		open();
		database.delete("schedules", "class_id=" + class_id+
		          " and classDay='" + classDay +
		          "' and startDate='" + startDate +
		          "' and endDate='" + endDate + "'", null);
		close();
	}
	
		
	public void deleteTaOfficeHours(String officeDay,String startTime,String endTime,long instructor_id,long assistant_id)
	{
		open();
		database.delete("officeHours", "assistant_id=" + assistant_id +
		          " and officeDay='" + officeDay +
		          "' and startTime='" + startTime +
		          "' and endTime='" + endTime + "'", null);
		close();
	}

	public void updateOfficeHoursForTa(String officeDay,String startTime,String endTime,long instructor_id,long assistant_id,long id)
	{
		count=count+1;
		open();
		Cursor cu=database.rawQuery("select * from officehours where assistant_id= "+assistant_id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		ContentValues updateOfficeHours=new ContentValues();
		updateOfficeHours.put("officeDay", officeDay);
		updateOfficeHours.put("startTime", startTime);
		updateOfficeHours.put("endTime", endTime);
		updateOfficeHours.put("instructor_id", instructor_id);
		updateOfficeHours.put("assistant_id", assistant_id);
		if(count>a)
		{
			open();
			database.insert("officehours", null, updateOfficeHours);
			close();
		}
		else
		{
			open();
			database.update("officehours", updateOfficeHours,"assistant_id=" + assistant_id +
			          " and officeDay='" + officeDay+"'",null);
			close();
		}

		
		//database.rawQuery("UPDATE officehours SET officeDay = \""+officeDay+"\",startTime= \""+startTime+"\",endTime= \""+endTime+"\",instructor_id= "+instructor_id+",assistant_id= "+assistant_id+" WHERE assistant_id= "+id+" AND officeDay= \""+officeDay+"\"", null);
		
	}

	public Cursor getAllTa()
	{
		open();
		Cursor cu=database.rawQuery("select _id,name from assistants", null);
		int y=cu.getCount();
		y=y+0;
		close();
		return cu;
	}
	
	public Cursor getAllClasses()
	{
		open();
		Cursor cu=database.rawQuery("select _id,name from classes", null);
		int y=cu.getCount();
		y=y+0;
		close();
		return cu;
	
		
	}

	public Cursor getInstructorOfficeHours(long id)
	{
		open();
		Cursor cu=database.rawQuery("select _id,officeDay,startTime,endTime from officehours where instructor_id= "+id+" order by officeDay", null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}

	public Cursor getTaOfficeHours(long id)
	{
		open();
		Cursor cu=database.rawQuery("select _id,officeDay,startTime,endTime from officehours where assistant_id= "+id+" order by officeDay", null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public long insertClasses(String courseNumber,String name, String description, String location, String startDate,String endDate,int numTargetedWeeklySessions)
	{
		ContentValues insertClasses=new ContentValues();
		insertClasses.put("courseNumber", courseNumber);
		insertClasses.put("name",name);
		insertClasses.put("description",description);
		insertClasses.put("location",location);
		insertClasses.put("startDate",startDate);
		insertClasses.put("endDate",endDate);
		insertClasses.put("numTargetedWeeklySessions",numTargetedWeeklySessions);
		
		open();
		long rowID=database.insert("classes", null, insertClasses);
		close();
		
		return rowID;
	}
	
	public long insertSchedule(String classDay,String startDate,String endDate,long class_id )
	{
		ContentValues insertSchedule=new ContentValues();
		insertSchedule.put("classDay", classDay);
		insertSchedule.put("startDate",startDate);
		insertSchedule.put("endDate",endDate);
		insertSchedule.put("class_id",class_id);
		
		open();
		long rowID=database.insert("schedules", null, insertSchedule);
		close();
		return rowID;
	}
	
	public int getInstructorId(String name)
	{
		open();
		Cursor cu=database.rawQuery("select _id from instructors where name= \""+name+"\"", null);
		int a=cu.getCount();
		a=a+0;
		close();
		cu.moveToFirst();
		int idIndex=cu.getColumnIndex("_id");
		int iD=cu.getInt(idIndex);
		return iD;
	}
	
	public int getTaId(String name)
	{
		open();
		Cursor cu=database.rawQuery("select _id from assistants where name= \""+name+"\"", null);
		int a=cu.getCount();
		a=a+0;
		close();
		cu.moveToFirst();
		int idIndex=cu.getColumnIndex("_id");
		int iD=cu.getInt(idIndex);
		return iD;
		
	}
	
	public void insertInstructorForClass(long class_id,int instructor_id)
	{
		ContentValues insertInstructorForClass=new ContentValues();
		insertInstructorForClass.put("instructor_id", instructor_id);
		insertInstructorForClass.put("class_id", class_id);
		open();
		database.insert("classInstructors", null, insertInstructorForClass);
		close();
		
	}
	
	public void insertTaForClass(long class_id,int assistant_id)
	{
		ContentValues insertTaForClass=new ContentValues();
		insertTaForClass.put("assistant_id", assistant_id);
		insertTaForClass.put("class_id", class_id);
		open();
		database.insert("classAssistants ", null, insertTaForClass);
		close();
	}
	
	
	public Cursor checkInstructorForClass(int instructor_id)
	{
		open();
		Cursor cu=database.rawQuery("select * from classInstructors where instructor_id= "+instructor_id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public Cursor checkTaForClass(int assistant_id)
	{
		open();
		Cursor cu=database.rawQuery("select * from classAssistants where assistant_id= "+assistant_id, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public void deleteInstructorForClass(long class_id,int instructor_id)
	{
		open();
		database.delete("classInstructors", "class_id=" + class_id +
		          " and instructor_id=" + instructor_id, null);
		close();
	}
	
	public void updateClassLocationAndDescription(long id,String classLocation,String classDescription)
	{
		ContentValues updateLocationAndDescription=new ContentValues();
		updateLocationAndDescription.put("description", classDescription);
		updateLocationAndDescription.put("location",classLocation);
		open();
		database.update("classes", updateLocationAndDescription,"_id=" + id , null);
		close();
		
	}
	
	public Cursor getClassInfo(long iD)
	{
		open();
		Cursor cu=database.rawQuery("select courseNumber,name,numTargetedWeeklySessions from classes where _id= "+iD, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public Cursor getScheduleForClass(long iD)
	{
		open();
		Cursor cu=database.rawQuery("select classDay,startDate,endDate from schedules where class_id= "+iD, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
		
	}
	
	public Cursor getAllInfoOfClasses(long iD)
	{
		open();
		Cursor cu=database.rawQuery("select * from classes where _id= "+iD, null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public void deleteClass(long iD)
	{
		open();
		database.delete("classes", "_id= "+iD, null);
		close();
	}
	
	public void deleteSpecificSchedule(long iD)
	{
		open();
		database.delete("schedules", "class_id= "+iD, null);
		close();
	}
	
	public void updateClass(String courseNumber,String name,String startDate,String endDate,int numTargetedWeeklySessions,long iD)
	{
		ContentValues updateClass=new ContentValues();
		updateClass.put("courseNumber", courseNumber);
		updateClass.put("name",name);
		updateClass.put("startDate",startDate);
		updateClass.put("endDate",endDate);
		updateClass.put("numTargetedWeeklySessions",numTargetedWeeklySessions);
		
		open();
		database.update("classes", updateClass,"_id=" + iD,null);
		close();
		
		
	}
	
	public Cursor getInstructorNamesFromClassInstructors(long iD)
	{
		open();
		Cursor cu=database.rawQuery("select _id, name from instructors where _id= "+"(select instructor_id from classInstructors where class_id= "+iD+")", null);
		int a=cu.getCount();
		a=a+0;
		close();
		return cu;
	}
	
	public Cursor getTaNamseFromClassAssistants(long iD)
	{
		open();
		Cursor cu=database.rawQuery("select _id, name from assistants where _id= "+"(select assistant_id from classAssistants where class_id= "+iD+")", null);
		int a=cu.getCount();
		a=a+0;
		return cu;
	}
	
	private class DatabaseOpenHelper extends SQLiteOpenHelper
	{
		public DatabaseOpenHelper(Context context,String name,CursorFactory factory,int version)
		{
			super(context,name,factory,version);
		}

		@Override
		public void onCreate(SQLiteDatabase db)
		{
			String createQuery="CREATE TABLE users"+
					"(_id integer primary key autoincrement,"+
					"FirstName TEXT, "+
					"LastName TEXT, "+
					"StudentID TEXT, "+
					"SchoolName TEXT, "+
					"Description TEXT, "+
					"Others TEXT, UNIQUE(StudentID) ON CONFLICT REPLACE);";
			db.execSQL(createQuery);

			createQuery="CREATE TABLE instructors" +
					"(_id integer primary key autoincrement," +
					"name TEXT, " +
					"office TEXT, " +
					"phone TEXT," +
					"email TEXT);";
			db.execSQL(createQuery);



			createQuery = "CREATE TABLE assistants" +
					"(_id integer primary key autoincrement," +
					"name TEXT, " +
					"office TEXT, " +
					"phone TEXT," +
					"email TEXT);";

			db.execSQL(createQuery); // execute the query

			createQuery = "CREATE TABLE officehours" +
					"(_id integer primary key autoincrement," +
					"officeDay TEXT, " +
					"startTime TEXT, " +
					"endTime TEXT, " +
					"instructor_id integer references instructors(_id) on delete cascade," +
					"assistant_id integer references assistants(_id) on delete cascade);"; 
			db.execSQL(createQuery); // execute the query
			
			 createQuery = "CREATE TABLE classes" +
	        		 "(_id integer primary key autoincrement," +
	                 "courseNumber TEXT, " +
	                 "name TEXT, " +
	                 "description TEXT, " +
	                 "location TEXT, " +
	                 "startDate TEXT, " +
	                 "endDate TEXT, " +
	                 "numTargetedWeeklySessions integer);"; 
	         db.execSQL(createQuery); 
	         
	         createQuery = "CREATE TABLE schedules" +
						"(_id integer primary key autoincrement," +
						"classDay TEXT, " +
						"startDate TEXT, " +
						"endDate TEXT, " +
						"class_id integer references classes(_id) on delete cascade);";
				db.execSQL(createQuery);
				
				 createQuery = "CREATE TABLE classInstructors" +
							"(_id integer primary key autoincrement," +
							"instructor_id integer references instructors(_id) on delete cascade," +
							"class_id integer references classes(_id) on delete cascade);";
				 
				 
				 db.execSQL(createQuery);
				 
				 createQuery = "CREATE TABLE classAssistants" +
							"(_id integer primary key autoincrement," +
							"assistant_id integer references assistants(_id) on delete cascade," +
							"class_id integer references classes(_id) on delete cascade);";
				 
				 
				 db.execSQL(createQuery);


		}

		@Override
		public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion)
		{

		}
	}

}

