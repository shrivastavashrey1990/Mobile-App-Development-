package com.example.projectv3;


import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
public class ViewClassInformation extends Activity {
	private TextView classNameTextView;
	private TextView courseNumberTextView;
	private TextView numberTargeted;
	private Spinner spinnerProfessorNames;
	private Spinner spinnerAssistantsName;
	private long classID;
	private TableLayout classTimeTableLayout;
	private Cursor c;
	private Cursor schedule;
	private List<String> professorNamesList;
	private List<String> assistantNamesList;
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_class_information_and_study_sessions);
		classNameTextView=(TextView)findViewById(R.id.classNameTextView);
		courseNumberTextView=(TextView)findViewById(R.id.courseNumberTextView);
		numberTargeted=(TextView)findViewById(R.id.textView12);
		spinnerProfessorNames=(Spinner)findViewById(R.id.spinnerProfessorName);
		spinnerAssistantsName=(Spinner)findViewById(R.id.spinnerAssistantsName);
		classTimeTableLayout=(TableLayout)findViewById(R.id.classTimeTableLayout);

		Button classViewEditButton=(Button)findViewById(R.id.classViewEditButton);
		classViewEditButton.setOnClickListener(classViewEditButtonListener);

		Button classDeleteViewButton=(Button)findViewById(R.id.classDeleteViewButton);
		classDeleteViewButton.setOnClickListener(classDeleteViewButtonListener);

		Bundle extras=getIntent().getExtras();
		classID=extras.getLong("classID");
		
		addItemsOnAssistantsSpinner();
		addItemsOnProfessorSpinner();

	}

	OnClickListener classDeleteViewButtonListener=new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatabaseConnector databaseconnector=new DatabaseConnector(ViewClassInformation.this);
			databaseconnector.deleteClass(classID);
			databaseconnector.deleteSpecificSchedule(classID);
			classTimeTableLayout.removeAllViews();
			Intent viewClass=new Intent(ViewClassInformation.this,ViewClasses.class);
			startActivity(viewClass);
		}
	};

	@Override
	protected void onResume()
	{
		super.onResume();
		new LoadClassInfo().execute(classID);
	}

	public void addItemsOnProfessorSpinner()
	{
		professorNamesList=new ArrayList<String>();
		DatabaseConnector databaseConnector=new DatabaseConnector(this);
		Cursor result=databaseConnector.getInstructorNamesFromClassInstructors(classID);
		int count=result.getCount();

		if(count>0)
		{
			result.moveToFirst();
			for(int a=1;a<=count;a++)
			{
				int nameIndex=result.getColumnIndex("name");
				String s=result.getString(nameIndex);
				System.out.println(s);
				professorNamesList.add(result.getString(nameIndex));
				result.moveToNext();
			}
			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, professorNamesList);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerProfessorNames.setAdapter(dataAdapter);
			result.close();
		}

	}

	public void addItemsOnAssistantsSpinner()
	{
		assistantNamesList=new ArrayList<String>();
		DatabaseConnector databaseConnector=new DatabaseConnector(this);
		Cursor result=databaseConnector.getTaNamseFromClassAssistants(classID);
		int count=result.getCount();
		if(count>0)
		{
			result.moveToFirst();
			for(int a=1;a<=count;a++)
			{
				int nameIndex=result.getColumnIndex("name");
				String s=result.getString(nameIndex);
				System.out.println(s);
				assistantNamesList.add(result.getString(nameIndex));
				result.moveToNext();
			}
			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
					android.R.layout.simple_spinner_item, assistantNamesList);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinnerAssistantsName.setAdapter(dataAdapter);
			result.close();
			
		}

	}

	OnClickListener classViewEditButtonListener=new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatabaseConnector databaseconnector=new DatabaseConnector(ViewClassInformation.this);
			Cursor a=databaseconnector.getAllInfoOfClasses(classID);
			a.moveToFirst();
			int courseNumber=a.getColumnIndex("courseNumber");
			int name = a.getColumnIndex("name");
			int numTargetedWeeklySessions=a.getColumnIndex("numTargetedWeeklySessions");
			int description=a.getColumnIndex("description");
			int location=a.getColumnIndex("location");
			int startDate=a.getColumnIndex("startDate");
			int endDate=a.getColumnIndex("endDate");

			Intent addClasses= new Intent(ViewClassInformation.this,AddClasses.class);
			addClasses.putExtra("courseNumber", a.getString(courseNumber));
			addClasses.putExtra("name",a.getString(name));
			addClasses.putExtra("numTargetedWeeklySessions",a.getInt(numTargetedWeeklySessions));
			addClasses.putExtra("description",a.getString(description));
			addClasses.putExtra("location",a.getString(location));
			addClasses.putExtra("startDate",a.getString(startDate));
			addClasses.putExtra("endDate",a.getString(endDate));
			classTimeTableLayout.removeAllViews();
			a.close();
			startActivity(addClasses);

		}
	};
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		MenuInflater inflator=getMenuInflater();
		inflator.inflate(R.menu.classes_view, menu);


		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case R.id.addNewClass:
			Intent addNewClass= new Intent(ViewClassInformation.this,AddClasses.class);
			startActivity(addNewClass);
			return super.onOptionsItemSelected(item);
			
		case R.id.keyOutcomesClass:
			Intent keyOutcomesClass= new Intent(ViewClassInformation.this,KeyOutcomes.class);
			startActivity(keyOutcomesClass);
			return super.onOptionsItemSelected(item);
			

		default: return super.onOptionsItemSelected(item); 
		}
	}
	private class LoadClassInfo extends AsyncTask<Long,Object,Cursor>
	{
		DatabaseConnector databaseconnector=new DatabaseConnector(ViewClassInformation.this);
		@Override
		protected Cursor doInBackground(Long... params)
		{
			c=databaseconnector.getClassInfo(params[0]);
			return c;
		}

		@Override
		protected void onPostExecute(Cursor result)
		{
			super.onPostExecute(result);
			int b=result.getCount();
			b=b+0;
			result.moveToFirst();

			int courseNumber=result.getColumnIndex("courseNumber");
			int name = result.getColumnIndex("name");
			int numTargetedWeeklySessions=result.getColumnIndex("numTargetedWeeklySessions");

			courseNumberTextView.setText(result.getString(courseNumber));
			classNameTextView.setText(result.getString(name));
			numberTargeted.setText(String.valueOf(result.getInt(numTargetedWeeklySessions)));
			result.close();
			schedule=databaseconnector.getScheduleForClass(classID);

			int i=schedule.getCount();
			schedule.moveToFirst();
			for(int z=1;z<=i;z++)
			{
				LayoutInflater inflater=(LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				View newViewDetails=inflater.inflate(R.layout.view_details, null);

				TextView nameTextView=(TextView)newViewDetails.findViewById(R.id.nametextView);
				int classDay=schedule.getColumnIndex("classDay");
				String s=schedule.getString(classDay);
				System.out.println(s);
				nameTextView.setText(schedule.getString(classDay));

				TextView startTimeTextView=(TextView)newViewDetails.findViewById(R.id.courseNumberTextView);
				int startTime=schedule.getColumnIndex("startDate");
				startTimeTextView.setText(schedule.getString(startTime));

				TextView endTimeTextView=(TextView)newViewDetails.findViewById(R.id.textView3);
				int endTime=schedule.getColumnIndex("endDate");
				endTimeTextView.setText(schedule.getString(endTime));

				classTimeTableLayout.addView(newViewDetails);
				schedule.moveToNext();




			}
			schedule.close();


		}
	}



}
