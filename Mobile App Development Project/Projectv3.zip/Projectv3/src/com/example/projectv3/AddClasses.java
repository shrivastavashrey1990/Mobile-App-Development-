package com.example.projectv3;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.view.LayoutInflater;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
public class AddClasses extends Activity {
	private long rowID;
	private long rowIdForEnteringClassLocation;
	private long classRowId;
	private EditText className;
	private EditText courseNumber;
	private EditText startDate;
	private EditText lasttDate;
	private EditText noOfSessions;
	private EditText classLocation;
	private EditText description;
	private Cursor markDays;
	private Bundle extras;
	private static Long markDaysId[]=new Long[4000];
	private Spinner spinnerInstructorName;
	private Spinner spinnerTaName;
	private TableLayout daysMarkedTableLayout;
	private int insertOrUpdate;

	@Override 
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_classes);
		className=(EditText)findViewById(R.id.classNameEditText);
		courseNumber=(EditText)findViewById(R.id.courseNumberEditText);
		startDate=(EditText)findViewById(R.id.startDateEditText);
		lasttDate=(EditText)findViewById(R.id.lastDateEditText);
		noOfSessions=(EditText)findViewById(R.id.numberOfSessionsEditText);

		daysMarkedTableLayout=(TableLayout)findViewById(R.id.daysMarkedTableLayout);

		Button monButton=(Button)findViewById(R.id.monButtonClass);
		Button tueButton=(Button)findViewById(R.id.tueButtonClass);
		Button wedButton=(Button)findViewById(R.id.wedButtonClass);
		Button thuButton=(Button)findViewById(R.id.thuButtonClass);
		Button friButton=(Button)findViewById(R.id.friButtonClass);
		Button satButton=(Button)findViewById(R.id.satButtonClass);

		Button saveFinishButton=(Button)findViewById(R.id.saveAndDeleteForClass);

		monButton.setOnClickListener(daysButtonListener);
		tueButton.setOnClickListener(daysButtonListener);
		wedButton.setOnClickListener(daysButtonListener);
		thuButton.setOnClickListener(daysButtonListener);
		friButton.setOnClickListener(daysButtonListener);
		satButton.setOnClickListener(daysButtonListener);


		saveFinishButton.setOnClickListener(saveAndFinishButtonListener);

		extras=getIntent().getExtras();
		if(extras!=null)
		{
			className.setText(extras.getString("Name"));
			courseNumber.setText(extras.getString("courseNumber"));
			startDate.setText(extras.getString("startDate"));
			lasttDate.setText(extras.getString("endDate"));
			noOfSessions.setText(extras.getString("numTargetedWeeklySessions"));

			rowID=extras.getLong("classID");
		}

	}

	OnClickListener daysButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(final View v)
		{
			makeClassDaysGUI(v.getId());
		}
	};

	private void makeClassDaysGUI(int dayId)
	{
		// get a reference to the LayoutInflater service
		LayoutInflater inflater = (LayoutInflater) getSystemService(
				Context.LAYOUT_INFLATER_SERVICE);

		View newClassDescriptionView = inflater.inflate(R.layout.new_class_description_row, null);

		TextView dayTextView = (TextView) newClassDescriptionView.findViewById(R.id.classDaytextView1);
		switch (dayId)
		{
		case R.id.monButtonClass: 
			dayTextView.setText("Mon");
			break;
		case R.id.tueButtonClass: 
			dayTextView.setText("Tue");
			break;
		case R.id.wedButtonClass: 
			dayTextView.setText("Wed");
			break;
		case R.id.thuButtonClass: 
			dayTextView.setText("Thu");
			break;
		case R.id.friButtonClass: 
			dayTextView.setText("Fri");
			break;
		case R.id.satButtonClass: 
			dayTextView.setText("Sat");
			break;
		}

		EditText startTimeEditText = (EditText) newClassDescriptionView.findViewById(R.id.classStartTimeEditText);
		startTimeEditText.setHint("start time");

		EditText endTimeEditText = (EditText) newClassDescriptionView.findViewById(R.id.classEndTimeEditText);
		endTimeEditText.setHint("end time");

		Button delClassDayButton = 
				(Button) newClassDescriptionView.findViewById(R.id.delClassDayButton);
		delClassDayButton.setOnClickListener(delClassDayButtonListener);

		daysMarkedTableLayout.addView(newClassDescriptionView);

	}

	OnClickListener delClassDayButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if(extras!=null)
			{
				DatabaseConnector databaseConnector = new DatabaseConnector(AddClasses.this);
				TableLayout table = (TableLayout)findViewById(R.id.daysMarkedTableLayout);
				TableRow classDayTableRow=(TableRow)v.getParent();
				
				Cursor result=databaseConnector.checkClassDayExistence(((TextView) classDayTableRow.getChildAt(0)).getText().toString(), rowID);
				if(result.getCount()>0)
				{
					databaseConnector.deleteClassDays(((EditText) classDayTableRow.getChildAt(0)).getText().toString(), //day
							((EditText) classDayTableRow.getChildAt(1)).getText().toString(), //start time
							((TextView) classDayTableRow.getChildAt(3)).getText().toString(), //end time
							rowID);
					table.removeView(classDayTableRow);

				}
				else
				{
					table.removeView(classDayTableRow);
				}



			}
			else
			{
				TableLayout table = (TableLayout)findViewById(R.id.daysMarkedTableLayout);
				TableRow officeHourTableRow=(TableRow)v.getParent();
				table.removeView(officeHourTableRow);

			}
		}
	};

	OnClickListener saveAndFinishButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if( className.getText().toString().trim().length()>0)
			{
				AsyncTask<Object, Object, Object> saveTask= new AsyncTask<Object,Object,Object>()
						{
					@Override
					protected Object doInBackground(Object... params)
					{
						if(extras!=null)
						{

							updateClass();
						}
						else
						{
							saveClass();
						}
						return null;

					}

					@Override
					protected void onPostExecute(Object result)
					{
						if(extras!=null)
						{
							Intent enterClassDetails=new Intent(AddClasses.this,EnterClassLocationAndDescription.class);
							enterClassDetails.putExtra("classID", rowID);
							enterClassDetails.putExtra("inertOrUpdate", insertOrUpdate);
							startActivity(enterClassDetails);

						}
						else
						{
							Intent enterClassDetails=new Intent(AddClasses.this,EnterClassLocationAndDescription.class);
							enterClassDetails.putExtra("classID", rowIdForEnteringClassLocation);
							startActivity(enterClassDetails);
							
						}


					}

						};
						saveTask.execute((Object[])null);
			}
			else
			{
				AlertDialog.Builder builder= new AlertDialog.Builder(AddClasses.this);
				builder.setTitle(R.string.errorTitle);
				builder.setMessage(R.string.errorMessage);
				builder.setPositiveButton(R.string.errorButton, null);
				builder.show();
			}	

		}



	};

	public void updateClass()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		databaseConnector.updateClass(courseNumber.getText().toString().trim(), className.getText().toString().trim(), startDate.getText().toString().trim(), lasttDate.getText().toString().trim(), Integer.parseInt(noOfSessions.getText().toString().trim()), rowID);
		for (int i = 0; i < daysMarkedTableLayout.getChildCount(); i++)
		{
			if(markDaysId[i]==null)
			{
				markDaysId[i]=0L;
			}
			TableRow daysTableRow = (TableRow) daysMarkedTableLayout.getChildAt(i);
			databaseConnector.updateSchedule(((EditText) daysTableRow.getChildAt(0)).getText().toString(), //day,
					((EditText) daysTableRow.getChildAt(1)).getText().toString(), //start time
					((TextView) daysTableRow.getChildAt(3)).getText().toString(), //end time
					rowID, markDaysId[i]);
			
		}
	}

	public void saveClass()
	{
		DatabaseConnector databaseConnector = new DatabaseConnector(this);
		classRowId=databaseConnector.insertClasses(courseNumber.getText().toString().trim(), className.getText().toString().trim(), "", "", startDate.getText().toString().trim(), lasttDate.getText().toString().trim(), Integer.parseInt(noOfSessions.getText().toString().trim()));
		rowIdForEnteringClassLocation=classRowId;
		for (int i = 0; i < daysMarkedTableLayout.getChildCount(); i++)
		{
			TableRow daysTableRow = (TableRow) daysMarkedTableLayout.getChildAt(i);
			markDaysId[i]=databaseConnector.insertSchedule(((EditText) daysTableRow.getChildAt(0)).getText().toString(), //day
					((EditText) daysTableRow.getChildAt(1)).getText().toString(), //start time
					((TextView) daysTableRow.getChildAt(3)).getText().toString(), //end time
					classRowId);
		}
	}



}
