package com.example.projectv3;
import android.app.Activity;
import android.os.Bundle;
public class ContactUs extends Activity {
	@Override
	protected void onCreate(Bundle savedInstance)
	{
		super.onCreate(savedInstance);
		setContentView(R.layout.contact_us);
	}

}
