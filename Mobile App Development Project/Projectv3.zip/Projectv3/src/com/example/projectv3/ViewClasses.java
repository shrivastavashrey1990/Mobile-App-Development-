package com.example.projectv3;


import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class ViewClasses extends ListActivity {
	public static final String ROW_ID = "row_id"; // Intent extra key
	private ListView viewClassesListView; // the ListActivity's ListView
	private CursorAdapter classesAdapter;

	@SuppressLint("ResourceAsColor")
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		viewClassesListView=getListView();
		viewClassesListView.setOnItemClickListener(viewClassesListViewListener);
		viewClassesListView.setBackgroundColor(Color.BLACK);
		


	}
	
	@Override
	protected void onResume()
	{
		super.onResume();
		saveClasses();

	}
	
	@Override
	protected void onStop()
	{
		Cursor cursor=classesAdapter.getCursor();
		if(cursor!=null)
		{
			cursor.deactivate();

		}
		classesAdapter.changeCursor(null);
		super.onStop();
	}


	public void saveClasses()
	{
		String from[]={"name"};
		int to[]={R.id.classesTextView};
		classesAdapter = new SimpleCursorAdapter(ViewClasses.this, R.layout.view_classes_and_study_sessions, null, from, to);
		setListAdapter(classesAdapter);
		new GetClassesList().execute((Object[])null);

	}

	private class GetClassesList extends AsyncTask<Object,Object,Cursor>
	{
		Cursor result;
		DatabaseConnector databaseConnector=new DatabaseConnector(ViewClasses.this);

		@Override
		protected Cursor doInBackground(Object... params)
		{
			result=databaseConnector.getAllClasses();
			return result;
		}

		@Override
		protected void onPostExecute(Cursor result)
		{
			classesAdapter.changeCursor(result);
		}

		
	}
	
	OnItemClickListener viewClassesListViewListener = new OnItemClickListener()
	{
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3)
		{
			Intent viewClassInformation= new Intent(ViewClasses.this,ViewClassInformation.class);
			viewClassInformation.putExtra("classID",arg3);
			startActivity(viewClassInformation);
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		MenuInflater inflator=getMenuInflater();
		inflator.inflate(R.menu.classes_view, menu);


		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case R.id.addNewClass:
			Intent addNewClass= new Intent(ViewClasses.this,AddClasses.class);
			startActivity(addNewClass);
			return super.onOptionsItemSelected(item);
			
		case R.id.keyOutcomesClass:
			Intent keyOutcomesClass= new Intent(ViewClasses.this,KeyOutcomes.class);
			startActivity(keyOutcomesClass);
			return super.onOptionsItemSelected(item);
			

		default: return super.onOptionsItemSelected(item); 
		}
	}

}
