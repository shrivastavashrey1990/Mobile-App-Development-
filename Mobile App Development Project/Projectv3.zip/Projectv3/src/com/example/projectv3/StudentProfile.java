package com.example.projectv3;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class StudentProfile extends Activity {
	private EditText firstNameEditText;
	private EditText lastNameEditText;
	private EditText studentIDeditText;
	private EditText schoolNameEditText;
	private EditText otherEditText;
	private EditText descriptionMultiLineEditText;
	private Button saveButton;
	private Long id=1L;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.student_profile);

		firstNameEditText=(EditText)findViewById(R.id.firstNameEditText);
		lastNameEditText=(EditText)findViewById(R.id.LastNameEditText);
		studentIDeditText=(EditText)findViewById(R.id.studentIDeditText);
		schoolNameEditText=(EditText)findViewById(R.id.schoolNameEditText);
		otherEditText=(EditText)findViewById(R.id.otherEditText);
		descriptionMultiLineEditText=(EditText)findViewById(R.id.descriptionMultiLineEditText);
		saveButton=(Button)findViewById(R.id.saveButton);
		saveButton.setOnClickListener(saveButtonListener);
	}
	
	@Override
	protected void onResume()
	{
		super.onResume();
		new LoadUserInfo().execute(id);
	}
	
	private class LoadUserInfo extends AsyncTask<Long,Object,Cursor>
	{
		DatabaseConnector databaseconnector=new DatabaseConnector(StudentProfile.this);
		@Override
		protected Cursor doInBackground(Long... params)
		{
			
			Cursor c= databaseconnector.getUserDetails(params[0]);
//			int a=c.getCount();
			//a=a+0;
			
			return c;
		}
		
		@Override
		protected void onPostExecute(Cursor result)
		{
			super.onPostExecute(result);
			int b=result.getCount();
			b=b+0;
			Cursor verifyResult=databaseconnector.getUserInfo();
			if(verifyResult.getCount()>0)
			{
				result.moveToFirst();
				int firstNameIndex= result.getColumnIndex("FirstName");
				String name=result.getString(firstNameIndex);
				System.out.println(name);
				firstNameEditText.setText(result.getString(firstNameIndex));
				
				int lastNameIndex= result.getColumnIndex("LastName");
				lastNameEditText.setText(result.getString(lastNameIndex));
				
				int StudentIDindex=result.getColumnIndex("StudentID");
				studentIDeditText.setText(result.getString(StudentIDindex));
				
				int schoolNameIndex=result.getColumnIndex("SchoolName");
				schoolNameEditText.setText(result.getString(schoolNameIndex));
				
				int otherIndex=result.getColumnIndex("Others");
				otherEditText.setText(result.getString(otherIndex));
				
				int description=result.getColumnIndex("Description");
				descriptionMultiLineEditText.setText(result.getString(description));
				
			}
			else
			{
				firstNameEditText.setText("");
				lastNameEditText.setText("");
				studentIDeditText.setText("");
				schoolNameEditText.setText("");
				otherEditText.setText("");
				descriptionMultiLineEditText.setText("");
			}
			result.close();
			
		}
	}
	
	OnClickListener saveButtonListener=new OnClickListener()
	{
		@Override
		public void onClick(View view)
		{
			
			
			Toast.makeText(StudentProfile.this, "Saving data...", Toast.LENGTH_SHORT).show();
			if(firstNameEditText.getText().toString()!=null && lastNameEditText.getText().toString()!=null && studentIDeditText.getText().toString()!=null && schoolNameEditText.getText().toString()!=null )
			{
				AsyncTask<Object, Object, Object> saveContactTask= new AsyncTask<Object, Object, Object>()
						{
					@Override
					public Object doInBackground(Object... params)
					{
						DatabaseConnector databaseconnector= new DatabaseConnector(StudentProfile.this);
						Cursor result=databaseconnector.getUserInfo();
						if(result.getCount()>0)
						{
							updateUser();
						}
						else
						{
							insertUser();
						}
						
						return null;
					}

					@Override
					protected void onPostExecute(Object result)
					{
						finish();
					}
						};
						saveContactTask.execute((Object[]) null);			
			}
			else
			{
				AlertDialog.Builder builder=new AlertDialog.Builder(StudentProfile.this);
				builder.setTitle(R.string.errorTitle);
				builder.setMessage(R.string.errorMessage);
				builder.setPositiveButton(R.string.errorButton, null);
				builder.show();

			}
		}
	};
	
	private void updateUser()
	{
		DatabaseConnector databaseconnector=new DatabaseConnector(this);
		int l=firstNameEditText.getText().toString().trim().length();
		System.out.println(l);
		if(firstNameEditText.getText().toString().trim().length()>0)
		{
			databaseconnector.updateUser(firstNameEditText.getText().toString(), 
						lastNameEditText.getText().toString(), 
						studentIDeditText.getText().toString(), 
						schoolNameEditText.getText().toString(), 
						descriptionMultiLineEditText.getText().toString(), 
						otherEditText.getText().toString());
				
		}
	}
	
	private void insertUser()
	{
		if(firstNameEditText.getText().length()>0)
		{
			DatabaseConnector databaseconnector= new DatabaseConnector(this);
			String sample=firstNameEditText.getText().toString();
			System.out.println(sample);
			databaseconnector.insertUser(firstNameEditText.getText().toString(), 
					lastNameEditText.getText().toString(), 
					studentIDeditText.getText().toString(), 
					schoolNameEditText.getText().toString(), 
					descriptionMultiLineEditText.getText().toString(), 
					otherEditText.getText().toString());
		}
	}

}
